// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
// https://developers.google.com/protocol-buffers/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Author: kenton@google.com (Kenton Varda)
//  Based on original Protocol Buffers design by
//  Sanjay Ghemawat, Jeff Dean, and others.

#ifndef GOOGLE_PROTOBUF_COMPILER_CPP_FILE_H__
#define GOOGLE_PROTOBUF_COMPILER_CPP_FILE_H__

#include <memory>
#include <string>
#include <vector>
#include <google/protobuf/stubs/common.h>
#include "google/protobuf/compiler/cpp/cpp_field.h"
#include "google/protobuf/compiler/cpp/cpp_options.h"

class BnetServiceGenerator;    // service.h

namespace google
{
    namespace protobuf
    {
        class FileDescriptor;        // descriptor.h
        namespace io
        {
            class Printer;             // printer.h
        }
    }

    namespace protobuf
    {
        namespace compiler
        {
            namespace cpp
            {

                class EnumGenerator;           // enum.h
                class MessageGenerator;        // message.h
                class ExtensionGenerator;      // extension.h
            }
        }
    }
}

namespace pb = google::protobuf;
namespace pbcpp = pb::compiler::cpp;

class BnetFileGenerator
{
public:
    // See generator.cc for the meaning of dllexport_decl.
    explicit BnetFileGenerator(const pb::FileDescriptor* file,
                               const pbcpp::Options& options);
    ~BnetFileGenerator();

    void GenerateHeader(pb::io::Printer* printer);
    void GenerateSource(pb::io::Printer* printer);

private:
    // Generate the BuildDescriptors() procedure, which builds all descriptors
    // for types defined in the file.
    void GenerateBuildDescriptors(pb::io::Printer* printer);

    void GenerateNamespaceOpeners(pb::io::Printer* printer);
    void GenerateNamespaceClosers(pb::io::Printer* printer);

    const pb::FileDescriptor* file_;

    pb::scoped_array<pb::scoped_ptr<pbcpp::MessageGenerator>> message_generators_;
    pb::scoped_array<pb::scoped_ptr<pbcpp::EnumGenerator>> enum_generators_;
    pb::scoped_array<pb::scoped_ptr<BnetServiceGenerator>> service_generators_;
    pb::scoped_array<pb::scoped_ptr<pbcpp::ExtensionGenerator>> extension_generators_;

    // E.g. if the package is foo.bar, package_parts_ is {"foo", "bar"}.
    std::vector<std::string> package_parts_;
    const pbcpp::Options options_;

    GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(BnetFileGenerator);
};

#endif  // GOOGLE_PROTOBUF_COMPILER_CPP_FILE_H__
